var squaresNum = 6;
var colors = [];
var pickedColor;

var squares = document.querySelectorAll(".square");
var colorDisplay = document.getElementById("pick");
var messageDisplay = document.getElementById("message");
var h1 = document.querySelector("h1");
var newGame = document.querySelector("#reset");
var easyBtn = document.querySelector("#easy");
var hardBtn = document.querySelector("#hard");
colorDisplay.textContent = pickedColor;

init();

function init(){
for (var i = 0; i < squares.length; i++){
	//initial colors
	squares[i].style.backgroundColor = colors[i];

	//click listeners
	squares[i].addEventListener("click", function(){
		//grab color of clicked square
		var clickedColor = this.style.backgroundColor;
		//compare colors
		if (clickedColor === pickedColor){
			messageDisplay.textContent = "Correct!";
			changeColors(clickedColor);
			h1.style.backgroundColor = clickedColor;
		}
		else{
			this.style.background = "#233333";
			messageDisplay.textContent = "Try Again!";
		}
	});
}
difficultyMode();
}

easyBtn.addEventListener("click",function(){
easyBtn.classList.add("selected");
hardBtn.classList.remove("selected");
squaresNum = 3;
difficultyMode();
});

hardBtn.addEventListener("click",function(){
easyBtn.classList.remove("selected");
hardBtn.classList.add("selected");
squaresNum = 6;
difficultyMode();
});

function difficultyMode(){
h1.style.backgroundColor = "steelblue";
messageDisplay.textContent = "";
newGame.textContent = "NEW COLORS";
colors = generateRandomColors(squaresNum);
pickedColor = pickColor();
colorDisplay.textContent = pickedColor;
for (var i = 0; i < squares.length; i++){
	if (colors[i]){
		squares[i].style.background = colors[i];
		squares[i].style.display = "block";
	}
	else{
		squares[i].style.display = "none";
	}
}
}



newGame.addEventListener("click", function(){
difficultyMode();
});

function changeColors(color){
	//loop all squares
	for (var i = 0; i < squares.length; i++){
	//change each color to match given color
	squares[i].style.backgroundColor = color;
}}

function pickColor(){
var random = Math.floor(Math.random() * colors.length);
return colors[random];
}

function generateRandomColors(num){
//make an array
var arr = []
//add num random colors to arr
for (var i = 0; i < num; i++){
	//get random color and push into arr
	arr.push(randomColor());
}
//return arr
return arr;
}

function randomColor(){
var r = Math.floor(Math.random() * 256);
var g = Math.floor(Math.random() * 256);
var b = Math.floor(Math.random() * 256);
return "rgb(" + r + ", " + g + ", " + b + ")";
}